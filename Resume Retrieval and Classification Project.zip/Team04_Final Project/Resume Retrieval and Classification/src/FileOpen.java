import java.awt.*;
import java.io.File;
public class FileOpen
{
    /**
     *
     * @param fileName file name to be opened
     */
    public void open(String fileName)
    {
        try
        {

            File file = new File("src/Resume/"+fileName);
            if(!Desktop.isDesktopSupported())
            {
                System.out.println("not supported");
            }
            Desktop desktop = Desktop.getDesktop();
            if(file.exists())
                desktop.open(file);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}