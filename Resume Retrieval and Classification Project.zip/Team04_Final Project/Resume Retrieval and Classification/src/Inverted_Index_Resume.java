import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

public class Inverted_Index_Resume {
    private ArrayList<String> dataLoaded;
    private ArrayList<String> termList;
    private ArrayList<ArrayList<Integer>> docLists;
    public ArrayList<Integer> result = new ArrayList<Integer>();
    String[] fileList;
    Merge m = new Merge();
    //constructor
    public Inverted_Index_Resume() throws IOException {
        ReadFiles rf = new ReadFiles();
        dataLoaded=rf.fileReader("src/Resume");
        File file = new File("src/Resume");
        fileList = file.list();
        termList = new ArrayList<String>();
        docLists = new ArrayList<ArrayList<Integer>>();
        ArrayList<Integer> docList;
        String[] myDocs = new String[dataLoaded.size()];
        ArrayList<String> stemmed_words = new ArrayList<String>();
        for (int j = 0; j < dataLoaded.size(); j++) {
            myDocs[j] = dataLoaded.get(j);
        }

        ParserA p=new ParserA();
        for (int i = 0; i < dataLoaded.size(); i++) {
            stemmed_words=p.parse(myDocs[i]);
            for (String word : stemmed_words) {
                if (!termList.contains(word)) {
                    termList.add(word);
                    docList = new ArrayList<Integer>();
                    docList.add(i);
                    docLists.add(docList);
                } else {
                    int index = termList.indexOf(word);
                    docList = docLists.get(index);
                    if (!docList.contains(i)) {
                        docList.add(i);
                        docLists.set(index, docList);

                    }
                }
            }

        }



    }

    /**
     *
     * @param query : string of query to be searched
     * @return doclist of the query term
     */
    public ArrayList<Integer> search(String query) {

        int index = termList.indexOf(query);
        if(index >= 0) {
            return docLists.get(index);
        }
        else return null;

    }

    /**
     *
     * @param query : string of query to be searched for AND operation
     * @return  doclist of the query terms with AND operation
     */
    public ArrayList<Integer> searchAnd(String[] query) {
        ArrayList<Integer> result = search(query[0]);
        int termId =1;
        while(termId < query.length) {
            ArrayList<Integer> result1 = search(query[termId]);
            if(result==null && result1 ==null) return null;
            result = m.mergeAnd(result, result1);
            termId++;
        }
        return result;
    }

    /**
     *
     * @return string to be printed in required format
     */





    public String toString() {
        String outputString = new String();
        StringBuilder output = new StringBuilder();
        for(int i=0;i<termList.size();i++) {
            outputString += String.format("%-30s", termList.get(i));
            ArrayList<Integer> docList = docLists.get(i);
            for(int j=0;j<docList.size();j++) {
                output.append(1+docList.get(j) + "\t");
            }
            output.append("\n");
        }
        outputString=output.toString();
        return outputString;
    }




}