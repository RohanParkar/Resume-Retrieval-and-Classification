import javax.swing.*;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;
import java.lang.String;
import java.io.File;
import javax.swing.filechooser.FileSystemView;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class Main  {


    public static void main(String[] args) throws IOException {

        //==========================================================ResumeRetrieval===============================================================

       // JFrame.setDefaultLookAndFeelDecorated(true);


        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception e) {
            e.printStackTrace();
        }
        Inverted_Index_Resume l1 = new Inverted_Index_Resume();
        ParserA p1 = new ParserA();


        JFrame frameRetrieval = new JFrame("Resume Retrieval");
        frameRetrieval.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frameRetrieval.setBounds(400, 300, 950, 500);



        JPanel panel = new JPanel();
        JLabel label = new JLabel("Enter Skills");
        JTextField tf = new JTextField(20);
        JButton search = new JButton("Search");
        JButton rank = new JButton("Top 5 resumes");

        panel.add(label);
        panel.add(tf);
        panel.add(search);
        panel.add(rank);

        JPanel panel2 = new JPanel();
        JLabel label2 = new JLabel("Select Resume Number:");
        JComboBox<String> jComboBox = new JComboBox<String>();
        jComboBox.addItem("Resume Number");
        JButton display = new JButton("Display");
        JButton back1 = new JButton("Back");
        JButton refresh1 = new JButton("Refresh");
        panel2.add(label2);
        panel2.add(jComboBox);
        panel2.add(display);
        panel2.add(back1);
        panel2.add(refresh1);


        JTextArea ta = new JTextArea();
        ta.setText("\nResume Retrieval" +
                "\n1. Enter the skills you want to find in a resume." +
                "\n2. Hit the search button to get the list of matching resumes." +
                "\n3. To view the listed resume select the number from the dropdown list below and press display." +
                "\n4. To get the top 5 matching resumes hit the top 5 resumes button. You can find them in the Ranked Resume folder." +
                "\n5. Refresh to search again." +
                "");
        ta.setFont(new Font("Serif",Font.PLAIN,20));


        frameRetrieval.getContentPane().add(BorderLayout.NORTH, panel);
        frameRetrieval.getContentPane().add(BorderLayout.CENTER, ta);
        frameRetrieval.getContentPane().add(BorderLayout.SOUTH, panel2);


        ActionListener searchResume = new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                String str = tf.getText();
                String[] input = p1.inputParser(str);
                if (input.length == 1) {
                   l1.result = l1.search(input[0]);
                    if (l1.result != null && l1.result.isEmpty() != true) {
                        jComboBox.removeAllItems();
                        jComboBox.addItem("Resume Number");
                        for(int i=0;i<l1.result.size();i++){
                            jComboBox.addItem((l1.result.get(i)).toString());
                        }

                        String output = "";
                        output = output + "Skills found in following files:\n";
                        output = output + "File: " + l1.result;
                        ta.setText(output);
                        ta.setLineWrap(true);
                    } else {
                        ta.setText("No match Found");
                    }

                } else if (input.length > 1) {
                        l1.result = l1.searchAnd(input);
                    if (l1.result != null && l1.result.isEmpty() != true) {
                        jComboBox.removeAllItems();
                        jComboBox.addItem("Resume Number");
                        for(int i=0;i<l1.result.size();i++){
                            jComboBox.addItem((l1.result.get(i)).toString());
                        }
                        String output = "";
                        output = output + "Skills found in following files:\n";
                        output = output + "File: " + l1.result;
                        ta.setText(output);
                        ta.setLineWrap(true);

                    } else {
                        ta.setText("No match Found");
                    }
                }


            }
        };
        search.addActionListener(searchResume);


        ActionListener displayResume = new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                try {
                    int match = 0;
                    String number = jComboBox.getSelectedItem().toString();
                    int n = Integer.parseInt(number);
                    for(int num:l1.result){
                        if(n==num) match=1;
                    }
                    if(match==1){
                        FileOpen f = new FileOpen();
                        f.open(l1.fileList[n]);
                    }
                    else{
                        JOptionPane.showMessageDialog(frameRetrieval, "File not present in the result!",
                                "Error", JOptionPane.ERROR_MESSAGE);
                    }

                }
                catch (Exception e){
                    JOptionPane.showMessageDialog(frameRetrieval, "File Not Found!",
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        };
        display.addActionListener(displayResume);

        ActionListener ranking = new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                try {
                    String str = tf.getText();
                    Files.createDirectories(Path.of("Ranked Resume\\Top 5 resumes for Query-"+str));
                    String[] input = p1.inputParser(str);
                    Rank_Search rs=new Rank_Search();
                    int[] rankList=rs.rank(input);
                    ta.setText("The top 5 matching resumes are:");
                    for(int i=0;i<5;i++){
                        ta.append("\n"+(i+1)+". Resume: "+rankList[i]);
                        String sfile ="src\\Resume\\"+l1.fileList[rankList[i]];
                        String dfile ="Ranked Resume\\Top 5 resumes for Query-"+str+"\\"+l1.fileList[rankList[i]];
                        FileReader fin = new FileReader(sfile);
                        FileWriter fout = new FileWriter(dfile, true);
                        int c;
                        while ((c = fin.read()) != -1) {
                            fout.write(c);
                        }
                        fin.close();
                        fout.close();
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        };
        rank.addActionListener(ranking);

        ActionListener back11 = new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                frameRetrieval.setVisible(false);
                ta.setText("\nResume Retrieval" +
                        "\n1. Enter the skills you want to find in a resume." +
                        "\n2. Hit the search button to get the list of matching resumes." +
                        "\n3. To view the listed resume select the number from the dropdown list below and press display." +
                        "\n4. To get the top 5 matching resumes hit the top 5 resumes button. You can find them in the Ranked Resume folder." +
                        "\n5. Refresh to search again." +
                        "");

                tf.setText("");
                jComboBox.removeAllItems();
                jComboBox.addItem("Resume Number");
            }
        };
        back1.addActionListener(back11);

        ActionListener refresh11 = new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                ta.setText("\nResume Retrieval" +
                        "\n1. Enter the skills you want to find in a resume." +
                        "\n2. Hit the search button to get the list of matching resumes." +
                        "\n3. To view the listed resume select the number from the dropdown list below and press display." +
                        "\n4. To get the top 5 matching resumes hit the top 5 resumes button. You can find them in the Ranked Resume folder." +
                        "\n5. Refresh to search again." +
                        "");

                tf.setText("");
                jComboBox.removeAllItems();
                jComboBox.addItem("Resume Number");
            }
        };
        refresh1.addActionListener(refresh11);
        //==========================================================Classification================================================================
        Vector_Space_Resume r = new Vector_Space_Resume();
        r.Accuracy();
        ParserB pb = new ParserB();

        JFrame frameClassify = new JFrame("Resume Classification");
        frameClassify.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frameClassify.setBounds(400, 200, 1200, 650);

        JPanel panelr = new JPanel();
        JLabel labelr = new JLabel("Choose Resume:");
        JTextField tfr = new JTextField(60);
        JButton browse = new JButton("Browse");
        JButton classify = new JButton("Classify");
        JButton back2 = new JButton("Back");
        JButton refresh = new JButton("Refresh");
        panelr.add(labelr);
        panelr.add(tfr);
        panelr.add(browse);
        panelr.add(classify);
        panelr.add(back2);
        panelr.add(refresh);

        JTextArea tar = new JTextArea();
        tar.setText("Classify any resume into various profiles." +
                "\n 1.Browse and select a resume in text format." +
                "\n 2. Hit the classify button to get the profile of the resume." +
                "\n 3. View the resume profile at the bottom of the window." +
                "\n" +
                "\n" +
                "\n You can profile a resume into following classes:" +
                "\n 1. Data Science" +
                "\n 2. HR" +
                "\n 3. Advocate" +
                "\n 4. Arts" +
                "\n 5. Web" +
                "\n 6. Mechanical Engineer" +
                "\n 7. Sales" +
                "\n 8. Health and fitness" +
                "\n 9. Civil Engineer" +
                "\n 10. Java Developer" +
                "\n 11. Business Analyst" +
                "\n 12. SAP Developer" +
                "\n 13. Automation Testing" +
                "\n 15. Electrical Engineering" +
                "\n 16. Operations Manager" +
                "\n 17. Python Developer" +
                "\n 18. DevOps Engineer" +
                "\n 19. Network Security Engineer" +
                "\n 20. PMO" +
                "\n 21. Database" +
                "\n 22. Hadoop" +
                "\n 23. ETL Developer" +
                "\n 24. DotNet Developer" +
                "\n 25. Blockchain" +
                "\n 26. Testing" +
                "");
        tar.setFont(new Font("Serif",Font.PLAIN,20));

        JScrollPane scroll = new JScrollPane(tar);

        JPanel panelo = new JPanel();
        JLabel tao = new JLabel();
        tao.setFont(new Font("Tahoma", Font.PLAIN, 19));
        panelo.add(tao);

        frameClassify.getContentPane().add(BorderLayout.NORTH, panelr);
        frameClassify.getContentPane().add(BorderLayout.CENTER, scroll);
        frameClassify.getContentPane().add(BorderLayout.SOUTH, panelo);

        ActionListener classifyResume = new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                Pattern pattern = Pattern.compile(".*\\.txt", Pattern.CASE_INSENSITIVE);
                String inputResume = "";
                String outputResume = "";
                StringBuilder input1;
                String filePath = tfr.getText();
                Matcher matcher = pattern.matcher(filePath);
                if(matcher.find()) {
                    Path fileName = Path.of(filePath);
                    Scanner sc = null;
                    try {
                        sc = new Scanner(fileName).useDelimiter("\n");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    input1 = new StringBuilder();
                    while (sc.hasNext()) {
                        input1.append(" " + sc.next());
                    }
                    try {
                        sc = new Scanner(fileName).useDelimiter("\n");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    inputResume = input1.toString();

                    input1 = new StringBuilder();
                    while (sc.hasNext()) {
                        input1.append("\n" + sc.next());
                    }
                    outputResume = input1.toString();
                    tar.setText(outputResume);

                    try {
                        inputResume = pb.parser(inputResume);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    inputResume = pb.stopwordsRemoval(inputResume);
                    String[] input = inputResume.split(" ");
                    tao.setText("The predicted resume profile is " + r.profileList[r.rankSearch(input)]);
                }
                else{
                    JOptionPane.showMessageDialog(frameRetrieval, "Only Text file allowed!",
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        };
        classify.addActionListener(classifyResume);

        ActionListener browseresume = new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
                int returnValue = jfc.showOpenDialog(null);
                if (returnValue == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = jfc.getSelectedFile();
                    String filePath = selectedFile.getAbsolutePath();
                    tfr.setText(filePath);
                }
            }
        };
        browse.addActionListener(browseresume);

        ActionListener back22 = new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                frameClassify.setVisible(false);
                tfr.setText("");
                tao.setText("");
                tar.setText("Classify any resume into various profiles." +
                        "\n 1.Browse and select a resume in text format." +
                        "\n 2. Hit the classify button to get the profile of the resume." +
                        "\n 3. View the resume profile at the bottom of the window." +
                        "\n" +
                        "\n" +
                        "\n You can profile a resume into following classes:" +
                        "\n 1. Data Science" +
                        "\n 2. HR" +
                        "\n 3. Advocate" +
                        "\n 4. Arts" +
                        "\n 5. Web" +
                        "\n 6. Mechanical Engineer" +
                        "\n 7. Sales" +
                        "\n 8. Health and fitness" +
                        "\n 9. Civil Engineer" +
                        "\n 10. Java Developer" +
                        "\n 11. Business Analyst" +
                        "\n 12. SAP Developer" +
                        "\n 13. Automation Testing" +
                        "\n 15. Electrical Engineering" +
                        "\n 16. Operations Manager" +
                        "\n 17. Python Developer" +
                        "\n 18. DevOps Engineer" +
                        "\n 19. Network Security Engineer" +
                        "\n 20. PMO" +
                        "\n 21. Database" +
                        "\n 22. Hadoop" +
                        "\n 23. ETL Developer" +
                        "\n 24. DotNet Developer" +
                        "\n 25. Blockchain" +
                        "\n 26. Testing" +
                        "");

            }
        };
        back2.addActionListener(back22);

        ActionListener refr = new ActionListener() {
            public void actionPerformed(ActionEvent event) {

                tfr.setText("");
                tao.setText("");
                tar.setText("Classify any resume into various profiles." +
                        "\n 1.Browse and select a resume in text format." +
                        "\n 2. Hit the classify button to get the profile of the resume." +
                        "\n 3. View the resume profile at the bottom of the window." +
                        "\n" +
                        "\n" +
                        "\n You can profile a resume into following classes:" +
                        "\n 1. Data Science" +
                        "\n 2. HR" +
                        "\n 3. Advocate" +
                        "\n 4. Arts" +
                        "\n 5. Web" +
                        "\n 6. Mechanical Engineer" +
                        "\n 7. Sales" +
                        "\n 8. Health and fitness" +
                        "\n 9. Civil Engineer" +
                        "\n 10. Java Developer" +
                        "\n 11. Business Analyst" +
                        "\n 12. SAP Developer" +
                        "\n 13. Automation Testing" +
                        "\n 15. Electrical Engineering" +
                        "\n 16. Operations Manager" +
                        "\n 17. Python Developer" +
                        "\n 18. DevOps Engineer" +
                        "\n 19. Network Security Engineer" +
                        "\n 20. PMO" +
                        "\n 21. Database" +
                        "\n 22. Hadoop" +
                        "\n 23. ETL Developer" +
                        "\n 24. DotNet Developer" +
                        "\n 25. Blockchain" +
                        "\n 26. Testing" +
                        "");

            }
        };
        refresh.addActionListener(refr);

        //==========================================================Main==========================================================================
        JFrame frameMain = new JFrame("Resume Retrieval and Classification");
        frameMain.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frameMain.setBounds(700, 300, 500, 500);
        frameMain.getContentPane().setLayout(null);
       // frameMain.getContentPane().setBackground(Color.lightGray);
        JLabel labelMain = new JLabel("Resume Retrieval and Classification ");
        labelMain.setFont(new Font("Tahoma", Font.PLAIN, 19));

        labelMain.setBounds(100, 0, 1000, 100);


        JButton retrieval = new JButton("Resume Retrieval");
        retrieval.setBounds(100, 100, 300, 100);
        JButton classification = new JButton("Resume Classification");
        classification.setBounds(100, 250, 300, 100);

        frameMain.getContentPane().add(labelMain);
        frameMain.getContentPane().add(retrieval);
        frameMain.getContentPane().add(classification);
        frameMain.setVisible(true);

        ActionListener retrievalBtn = new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                frameRetrieval.setVisible(true);
            }
        };
        retrieval.addActionListener(retrievalBtn);

        ActionListener classifyBtn = new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                frameClassify.setVisible(true);
            }
        };
        classification.addActionListener(classifyBtn);

    }

    }

