

import java.util.ArrayList;
import java.util.Collections;

public class Merge {
    /**
     *
     * @param a1 : doclist of first query term
     * @param a2 : doclist of second query term
     * @return merged doclist of both the terms with AND operation
     */
    public ArrayList<Integer> mergeAnd(ArrayList<Integer> a1, ArrayList<Integer> a2) {
        ArrayList<Integer> mergeList = new ArrayList<Integer>();
        Collections.sort(a1);
        //System.out.println(a1);
        Collections.sort(a2);
        //System.out.println(a2);

        int p1=0, p2=0;
        while(p1<a1.size() && p2<a2.size()) {
            if(a1.get(p1).intValue() == a2.get(p2).intValue()) {
                mergeList.add(a1.get(p1));
                p1++;
                p2++;
            }
            else if(a1.get(p1).intValue() < a2.get(p2).intValue()) p1++;
            else p2++;
        }
        return mergeList;
    }

}
