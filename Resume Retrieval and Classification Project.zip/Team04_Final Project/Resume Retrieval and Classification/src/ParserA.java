

import java.io.IOException;
import java.util.ArrayList;
import java.lang.StringBuilder;

public class ParserA {
    private String document;
    ReadFiles r = new ReadFiles();
    ArrayList<String> stopWordsList;
    {
        try {
            stopWordsList = r.stopWordReader("src/stopwords.txt");//Change the file path accordingly

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     *
     * @param docs : document in the form of a string that needs to be parsed
     * @return parsed document in the form ArrayList of stemmed words
     * @throws IOException
     */
    public ArrayList<String> parse(String docs) throws IOException {
        this.document = docs;
        ArrayList<String> pureWords = new ArrayList<String>();
        ArrayList<String> stemms = new ArrayList<String>();

        //Inverted_Index_Lab1 a = new Inverted_Index_Lab1();
        //System.out.println(myDocs[i]);
        document=removeAllDigit(document);
        document=document.toLowerCase();
        document=document.replaceAll("\\s+", " ");
        document=document.replaceAll("�", "");
        String[] words = this.document.split("[ \".,#<>$%=&-*/?\\;+:!-]+"); //tokenization
        pureWords = new ArrayList<String>();
        //System.out.println("Before Stop words:"+words);
        for (String w : words) {
            //System.out.println(word);
            if (searchStopWord(w) == -1) {
                pureWords.add(w);
            }
        }

        Stemmer st = new Stemmer();
        stemms = new ArrayList<String>();
        for (String token : pureWords) {
            st.add(token.toCharArray(), token.length());
            st.stem();
            stemms.add(st.toString());
            st = new Stemmer();
        }

        return stemms;
    }

    /**
     *
     * @param input : input query to be searched
     * @return parsed query
     */
    public String[] inputParser(String input){
        String[] tokens=input.split(" ");
        Stemmer st = new Stemmer();
        ArrayList<String> stems = new ArrayList<String>();
        for (String token : tokens) {
            st.add(token.toCharArray(), token.length());
            st.stem();
            stems.add(st.toString());
            st = new Stemmer();
        }
        String[] output = new String[stems.size()];
        for(int j =0;j<stems.size();j++){
            output[j] = stems.get(j);
        }

        return output;
    }

    /**
     *
     * @param key : word to be searched in the stopwords list
     * @return -1 if word not found and mid if word found
     */
    public int searchStopWord(String key) {
        int lo = 0;
        int hi = this.stopWordsList.size() - 1;

        while(lo <= hi) {
            int mid = lo + (hi - lo) / 2;
            int result = key.compareTo(this.stopWordsList.get(mid));
            if (result < 0) {
                hi = mid - 1;
            } else {
                if (result <= 0) {
                    return mid;
                }

                lo = mid + 1;
            }
        }

        return -1;
    }

    /**
     *
     * @param str : input string that has to get rid of digits
     * @return string containing only characters
     */
    public static String removeAllDigit(String str)
    {
        char[] charArray = str.toCharArray();
        StringBuilder result1 =new StringBuilder();
        String result;

        for (int i = 0; i < charArray.length; i++) {

            if (!Character.isDigit(charArray[i])) {
                //result = result + charArray[i];
                result1.append(charArray[i]);
            }
        }
        result=result1.toString();
        return result;
    }

}
