

import java.io.IOException;
import java.util.ArrayList;

public class ParserB {
    private String document;

    /**
     * @param docs : document in the form of a string that needs to be parsed
     * @return parsed document in the form of cleaned string
     * @throws IOException
     */
    public String parser(String docs) throws IOException {
        this.document = docs;
        document = document.replaceAll("[\".,#<>$%=&-*/?\\;+:!-]+", "");
        document = document.replaceAll("\\W", " ");
        document = document.replaceAll("[0-9]", "");
        document = document.replaceAll("\\s{1,}", " ");
        document = document.toLowerCase();
        return document;
    }

    /**
     *
     * @param doc string input to remove stopwords
     * @return stopwords free string
     */

    public String stopwordsRemoval(String doc){

        ReadFiles r = new ReadFiles();
        ArrayList<String> stopWordsList;
        String regex;
        try {
            stopWordsList = r.stopWordReader("src/stopwords.txt");//Change the file path accordingly
            for(String sw:stopWordsList){
                if(doc.contains(sw)){
                    regex=String.format("\\b%s\\b",sw);
                    doc=doc.replaceAll(regex,"") ;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        doc= doc.replaceAll("\\s{1,}", " ");
        return doc;
    }


}




