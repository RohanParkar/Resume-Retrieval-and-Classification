import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class Rank_Search {
    private ArrayList<String> dataLoaded;
    private ArrayList<String> termList;
    ArrayList<ArrayList<Doc>> docLists;
    public ArrayList<Integer> result = new ArrayList<Integer>();
    String[] fileList;
    double[] docLength;
    String[] myDocs;
//constructor
    public Rank_Search() throws IOException {
        ReadFiles rf = new ReadFiles();
        dataLoaded=rf.fileReader("src/Resume");
        File file = new File("src/Resume");
        fileList = file.list();
        termList = new ArrayList<String>();
        docLists = new ArrayList<ArrayList<Doc>>();
        ArrayList<Doc> docList;
        myDocs = new String[dataLoaded.size()];
        ArrayList<String> stemmed_words = new ArrayList<String>();
        for (int j = 0; j < dataLoaded.size(); j++) {
            myDocs[j] = dataLoaded.get(j);
        }

        for(int i=0;i<myDocs.length;i++)
        {
            String[] tokens = myDocs[i].split(" ");
            String token;
            for(int j=0;j<tokens.length;j++){
                token = tokens[j];
                if(!termList.contains(token))
                {
                    termList.add(token);
                    docList = new ArrayList<Doc>();
                    Doc doc = new Doc(i,1);
                    docList.add(doc);
                    docLists.add(docList);
                }
                else
                {
                    int index = termList.indexOf(token);
                    docList = docLists.get(index);
                    int k=0;
                    boolean match = false;

                    for(Doc doc:docList)
                    {
                        if (doc.docId == i)
                        {
                            doc.tw++;
                            match = true;
                            break;
                        }
                        k++;
                    }
                    if(!match)
                    {
                        Doc doc = new Doc(i,1);
                        docList.add(doc);
                    }
                }
            }
        }


        int N = myDocs.length;
        docLength = new double[N];
        for(int i=0;i<termList.size();i++){
            docList = docLists.get(i);
            int df = docList.size();
            Doc doc;
            for(int j=0;j<docList.size();j++){
                doc = docList.get(j);
                double tfidf = (1+Math.log(doc.tw))*Math.log(N/(df*1.0));
                docLength[doc.docId] += Math.pow(tfidf, 2);
                doc.tw = tfidf;
                docList.set(j, doc);
            }
        }
        //update the length
        for(int i=0;i<N;i++){
            docLength[i] = Math.sqrt(docLength[i]);
        }


    }
    /**
     *
     * @param query input to check for similarity with the different classes
     * @return list of ranked documents
     */
    public int[] rank(String[] query){

        HashMap<Integer, Double> docs = new HashMap<Integer, Double>();
        double queryLength=0;
        ArrayList<Doc> docList;

        for(String term:query) {
            int index = termList.indexOf(term);
            if(index <0) continue;
            docList = docLists.get(index);
            double qtfidx = (1 + Math.log10(1)) * Math.log10(myDocs.length)* 1.0/docList.size();
            queryLength+= Math.pow(qtfidx,2);
            Doc doc;
            for(int i=0;i<docList.size();i++) {
                doc = docList.get(i);
                double score = doc.tw * qtfidx;

                if(!docs.containsKey(doc.docId)) {
                    docs.put(doc.docId, score);
                }
                else {
                    score += docs.get(doc.docId);
                    docs.put(doc.docId, score);
                }
            }
        }
        queryLength = Math.sqrt(queryLength);
        double[] values = new double[docs.size()];
        int[] id = new int[docs.size()];
        int i = 0;
        for(int docID : docs.keySet()){
            double normalizedScore = docs.get(docID)/(docLength[docID]*queryLength);
            docs.put(docID, normalizedScore);
            values[i]=docs.get(docID);
            id[i]=docID;
            i++;
        }
        int tempId = 0;
        double tempValue;
        //Sort the array in ascending order using two for loops
        for (int j = 0; j <values.length; j++) {
            for (int k = j+1; k <values.length; k++) {
                if(values[j] < values[k]) {      //swap elements if not in order
                    tempValue = values[j];
                    tempId=id[j];
                    values[j] = values[k];
                    id[j]=id[k];
                    values[k] = tempValue;
                    id[k] = tempId;
                }
            }
        }

        return id;
    }





}
