
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class ReadFiles {
    ArrayList<String> stopWords = new ArrayList<String>();

    /**
     *
     * @param filePath : path where the folder is located from which data is to be read
     * @return data loaded from the files in the folder in an ArrayList
     * @throws IOException
     */
    public ArrayList<String> fileReader(String filePath) throws IOException {
        StringBuilder data1;
        ArrayList<String> fileData = new ArrayList<String>();
        File dir = new File(filePath);
        File[] files = dir.listFiles();
        for (File file : files) {
            data1 = new StringBuilder();
            String data="";
            if (file.isFile()) {
                BufferedReader inputStream = null;
                String line;
                try {
                    inputStream = new BufferedReader(new FileReader(file));
                    while ((line = inputStream.readLine()) != null) {
                        data1.append(line);
                    }
                } catch (IOException e) {
                    System.out.println(e);
                } finally {
                    data=data1.toString();
                    fileData.add(data);
                    if (inputStream != null) {
                        inputStream.close();
                    }
                }
            }

        }
        return fileData;
    }

    /**
     *
     * @param filePath : path where the stopword file is located
     * @return stopwords loaded from the file in an ArrayList
     * @throws IOException
     */
    public ArrayList<String> stopWordReader(String filePath) throws IOException{
        BufferedReader inputStream = null;
        String sw;
        try {
            inputStream = new BufferedReader(new FileReader(filePath));
            while ((sw = inputStream.readLine()) != null) {
                stopWords.add(sw);
                // System.out.println(sw);
            }
        } catch (IOException e) {
            System.out.println(e);
        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
        }
        return stopWords;
    }
}
