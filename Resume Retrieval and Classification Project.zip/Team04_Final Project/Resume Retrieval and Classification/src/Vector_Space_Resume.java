import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class Vector_Space_Resume {
    String[] myDocs = new String[26];
    ArrayList<String> termList;
    ArrayList<ArrayList<Doc>> docLists;
    double[] docLength;

    ArrayList<String> record = new ArrayList<String>();
    ArrayList<String> Resume_Profile = new ArrayList<String>();
    ArrayList<String> Class_Value = new ArrayList<String>();
    ArrayList<String> Resume = new ArrayList<String>();
    String[] profileList = new String[26];
    public int[] class_value;
    public String[] resume;
    public int[] test_class_value=new int[34];
    public String[] test_resume=new String[34];

    //constructor
    public Vector_Space_Resume() throws IOException {
        String[] line;
        Scanner sc = new Scanner(new File("src/resume_dataset.csv"));
        sc.useDelimiter("\n");
        sc.nextLine();
        while (sc.hasNext()) {
            record.add(sc.next());
        }
        sc.close();
        for (String data : record) {
            line = data.split(",");
            Resume_Profile.add(line[0]);
            Class_Value.add(line[1]);
            Resume.add(line[2]);
        }
        int size = Resume.size();
        String[] resume_profile = new String[size];
        class_value = new int[size];
        resume = new String[size];
        for (int i = 0; i < size; i++) {
            resume_profile[i] = Resume_Profile.get(i);
            resume[i] = Resume.get(i);
            class_value[i] = Integer.parseInt(Class_Value.get(i));
        }
        ParserB p = new ParserB();
        for (int i = 0; i < size; i++) {
            resume[i] = p.parser(resume[i]);
            resume[i] = p.stopwordsRemoval(resume[i]);
        }
        for (int i = 0; i < 26; i++) {
            myDocs[i] = "";
        }
        for (int i = 0,k=0; i < size; i++) {
            if(i%5==0){
                test_resume[k]=resume[i];
                test_class_value[k]=class_value[i];
                //System.out.println(test_class_value[k]+test_resume[k]);
                k++;
            }
            else {
                myDocs[class_value[i]] = myDocs[class_value[i]] + " " + resume[i];
                profileList[class_value[i]] = resume_profile[i];
            }
        }


        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++VECTOR Building+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        termList = new ArrayList<String>();
        docLists = new ArrayList<ArrayList<Doc>>();
        ArrayList<Doc> docList;
        for (int i = 0; i < myDocs.length; i++) {
            String[] tokens = myDocs[i].split(" ");
            String token;
            for (int j = 0; j < tokens.length; j++) {
                token = tokens[j];
                if (!termList.contains(token)) {
                    termList.add(token);
                    docList = new ArrayList<Doc>();
                    Doc doc = new Doc(i, 1);
                    docList.add(doc);
                    docLists.add(docList);
                } else {
                    int index = termList.indexOf(token);
                    docList = docLists.get(index);
                    int k = 0;
                    boolean match = false;

                    for (Doc doc : docList) {
                        if (doc.docId == i) {
                            doc.tw++;
                            match = true;
                            break;
                        }
                        k++;
                    }
                    if (!match) {
                        Doc doc = new Doc(i, 1);
                        docList.add(doc);
                    }
                }
            }
        }


        int N = myDocs.length;
        docLength = new double[N];
        for (int i = 0; i < termList.size(); i++) {
            docList = docLists.get(i);
            int df = docList.size();
            Doc doc;
            for (int j = 0; j < docList.size(); j++) {
                doc = docList.get(j);
                double tfidf = (1 + Math.log(doc.tw)) * Math.log(N / (df * 1.0));
                docLength[doc.docId] += Math.pow(tfidf, 2);
                doc.tw = tfidf;
                docList.set(j, doc);
            }
        }
        for (int i = 0; i < N; i++) {
            docLength[i] = Math.sqrt(docLength[i]);
        }
    }
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    /**
     *
     * @param query input to check for similarity with the different classes
     * @return
     */
    public int rankSearch(String[] query) {
        HashMap<Integer, Double> docs = new HashMap<Integer, Double>();
        double queryLength=0;
        ArrayList<Doc> docList;
        int id = 0;
        for (String term : query) {
            int index = termList.indexOf(term);
            if (index < 0) continue;
            id = 0;
            docList = docLists.get(index);
            double qtfidx = (1 + Math.log10(1)) * Math.log10(myDocs.length) * 1.0 / docList.size();
            queryLength+= Math.pow(qtfidx,2);
            Doc doc;
            for (int i = 0; i < docList.size(); i++) {
                doc = docList.get(i);
                double score = doc.tw * qtfidx;

                if (!docs.containsKey(doc.docId)) {
                    docs.put(doc.docId, score);
                } else {
                    score += docs.get(doc.docId);
                    docs.put(doc.docId, score);
                }

            }
        }
        //Normalization
        queryLength = Math.sqrt(queryLength);
        double max = 0;
        for(int docID : docs.keySet()){
            double normalizedScore = docs.get(docID)/(docLength[docID]*queryLength);
            docs.put(docID, normalizedScore);
            if (normalizedScore > max) {
                max = normalizedScore;
                id = docID;
            }
        }
        //System.out.println(docs);
        return id;
    }

    /**
     * Return the string representation of the index
     */


    public void Accuracy(){
        int total= test_resume.length;

        int correct=0;
        for (int i = 0; i < total; i++) {
            if(test_class_value[i] == rankSearch(test_resume[i].split(" ")));
                correct++;
        }
        double accuracy= 100.0 * correct / total;
        System.out.println("\nThe accuracy for vector space model used for document classification is "+accuracy+"%.");

    }


}
